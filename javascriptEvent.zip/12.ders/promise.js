function bilgigetir(data){
    return new Promise(function(resolve,reject){
        setTimeout(function(){
            resolve(data)
        },3000)
    })
}
function bilgigetir2(data){
    return new Promise(function(resolve,reject){
        setTimeout(function(){
            resolve(data)
        },5000)
    })
}
bilgigetir2("berat").then(response=>console.log(response))
console.log("kaan")
bilgigetir("özkal").then(function(response){
    console.log(response);
})
function sayikontrol(sayi){
    return new Promise((resolve,reject)=>{
        if(sayi%2==0){
            resolve("tebrikler kazandınız")
        }
        {
            reject("kaybettiniz")
        }
    })
}
sayikontrol(5)
.then(x=>console.log(x))
.catch(e=>console.log(e))