let bilgigetir=()=>{
    console.log("bilgi 1")
    setTimeout(()=>{
        console.log("bilgi 2")
    },4000)
    console.log("bilgi 3")
}
// bilgigetir()


bilgigetir2= async  ()=>{
    console.log("bilgi 1")
    await new Promise((resolve,reject)=>{
        setTimeout(()=>{
            resolve(console.log("bilgi 2"))
        },3000)
    })
    console.log("bilgi 3")
}
bilgigetir2()